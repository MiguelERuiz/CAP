//
// timing.h
//

#ifndef TIMING_H_INCLUDED
#define TIMING_H_INCLUDED

double wtime(void);

#endif /* TIMING_H_INCLUDED */
