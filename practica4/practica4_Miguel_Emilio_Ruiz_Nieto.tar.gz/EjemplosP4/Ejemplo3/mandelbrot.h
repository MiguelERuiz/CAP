#pragma acc routine seq
unsigned char mandelbrot(int Px, int Py);

