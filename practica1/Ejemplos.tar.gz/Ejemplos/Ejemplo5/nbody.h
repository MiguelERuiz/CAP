#ifndef NBODY_H
#define NBODY_H

typedef struct { float m, x, y, z, vx, vy, vz; } body;

#endif
