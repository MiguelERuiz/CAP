#ifndef GTIME_H
#define GTIME_H

double get_time();

#endif
