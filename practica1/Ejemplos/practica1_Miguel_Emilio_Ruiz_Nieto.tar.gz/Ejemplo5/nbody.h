#ifndef NBODY_H
#define NBODY_H

typedef struct {
    float *m;
    float *x;
    float *y;
    float *z;
    float *vx;
    float *vy;
    float *vz;
} body;

#endif
